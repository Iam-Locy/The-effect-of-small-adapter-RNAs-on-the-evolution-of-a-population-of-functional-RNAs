"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = exports["default"] = JSON.parse("{\n    \"DISCONSTACK\": -2.1,\n    \"POTWCPAIRMM\": -0.4,\n    \"POTGUPAIRMM\": -0.2\n}");