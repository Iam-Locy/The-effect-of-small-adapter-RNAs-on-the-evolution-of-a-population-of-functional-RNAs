import getBondSites from "./functions/getBondSites.js";
import getFunctionalSites from "./functions/getFunctionalSites.js";
import fold from "./fold.js";
import Struct from "./struct.js";

const foldWithAdapter = (rna, adapter) => {
    const functionalSites = Array.from(
        getFunctionalSites(adapter.seq, adapter.str[0])
    );

    let best = new Struct(0);

    functionalSites.map((site) => {
        const bondSites = getBondSites(rna, site);
        if (bondSites.mfe < best.mfe) best = bondSites;
    });

    let out = Array.from(rna);

    if (best.mfe < 0) {
        let blocked = best.pairs.map((pair) => {
            return pair[1];
        });

        blocked.forEach((index) => {
            out[index] = "X";
        });
    }

    return fold(out.join(""));
};

export default foldWithAdapter;
