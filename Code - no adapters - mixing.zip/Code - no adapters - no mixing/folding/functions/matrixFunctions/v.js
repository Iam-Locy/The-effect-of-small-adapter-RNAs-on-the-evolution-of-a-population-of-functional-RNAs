"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _hairpin = _interopRequireDefault(require("../energyFunctions/hairpin"));
var _stack = _interopRequireDefault(require("../energyFunctions/stack"));
var _internalLoop = _interopRequireDefault(require("../energyFunctions/internalLoop"));
var _bulge = _interopRequireDefault(require("../energyFunctions/bulge"));
var _wm = _interopRequireDefault(require("./wm"));
var _struct = _interopRequireDefault(require("../../struct"));
var _multiBranchLoopEnergies = _interopRequireDefault(require("../../lookupTables/multiBranchLoopEnergies"));
var _pairs = _interopRequireDefault(require("../../lookupTables/pairs"));
var _terminalMismatch = _interopRequireDefault(require("../energyFunctions/terminalMismatch"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const PAIRS = _pairs.default.ALL;
const v = (seq, i, j, matrices) => {
  if (matrices.v[i][j] != undefined) return matrices.v[i][j];
  let V = new _struct.default(Infinity);
  if (j - i <= 3 || !PAIRS.includes(seq[i] + seq[j])) {
    matrices.v[i][j] = V;
    return V;
  }
  let struct1 = new _struct.default((0, _hairpin.default)(seq, i, j), {
    pairs: [[i, j]]
  });
  let struct2 = new _struct.default(Infinity);
  for (let p = i + 1; p < j - 4; p++) {
    for (let q = p + 4; q < j; q++) {
      if (!PAIRS.includes(seq[p] + seq[q])) continue;
      const IS_STACK = p == i + 1 && q == j - 1;
      const IS_INTERIOR_LOOP = p != i + 1 && q != j - 1;
      const IS_BULGE = !(IS_STACK || IS_INTERIOR_LOOP);
      let e = Infinity;
      if (IS_STACK) {
        e = (0, _stack.default)(seq, i, j, p, q);
      }
      if (IS_INTERIOR_LOOP) {
        e = (0, _internalLoop.default)(seq, i, j, p, q);
      }
      if (IS_BULGE) {
        e = (0, _bulge.default)(seq, i, j, p, q);
      }
      let innerStruct = _struct.default.clone(v(seq, p, q, matrices));
      if (e + innerStruct.mfe < struct2.mfe) {
        innerStruct.addPair(e, [i, j]);
        struct2 = innerStruct;
      }
    }
  }
  let struct3 = new _struct.default(Infinity);
  for (let k = i + 1; k < j - 1; k++) {
    let innerStruct = _struct.default.merge((0, _wm.default)(seq, i + 1, k, matrices), (0, _wm.default)(seq, k + 1, j - 1, matrices));
    innerStruct.addPair(_multiBranchLoopEnergies.default.A, [i, j]);
    innerStruct.addExterior((0, _terminalMismatch.default)(seq, i, j, i + 1, j - 1), [i + 1, j - 1]);
    if (innerStruct.mfe < struct3.mfe) {
      struct3 = innerStruct;
    }
  }
  [struct1, struct2, struct3].forEach(s => {
    if (s.mfe < V.mfe) V = s;
  });
  matrices.v[i][j] = V;
  return V;
};
var _default = exports.default = v;