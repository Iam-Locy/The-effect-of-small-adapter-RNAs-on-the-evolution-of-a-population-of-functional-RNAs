"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _pairTable = _interopRequireDefault(require("./pairTable"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const bpDistance = (struct1, struct2) => {
  const table1 = (0, _pairTable.default)(struct1);
  const table2 = (0, _pairTable.default)(struct2);
  let dist = 0;
  const n = table1[0] < table2[0] ? table1[0] : table2[0];
  for (let i = 1; i <= n; i++) {
    if (table1[i] != table2[i]) {
      if (table1[i] > i) {
        dist++;
      }
      if (table2[i] > i) {
        dist++;
      }
    }
  }
  return dist;
};
var _default = exports.default = bpDistance;