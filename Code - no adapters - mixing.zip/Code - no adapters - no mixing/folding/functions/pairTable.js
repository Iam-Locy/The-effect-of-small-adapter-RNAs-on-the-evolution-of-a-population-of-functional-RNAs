"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
const pairTable = struct => {
  const n = struct.length;
  let open = "(";
  let close = ")";
  let stack = [];
  let table = Array(n + 1).fill(0);
  table[0] = n;
  for (let hx = 0, i = 1, j, index = 0; i <= n && index < n; i++, index++) {
    if (struct[index] == open) {
      stack[hx++] = i;
    } else if (struct[index] == close) {
      j = stack[--hx];
      table[i] = j;
      table[j] = i;
    }
  }
  return table;
};
var _default = exports.default = pairTable;