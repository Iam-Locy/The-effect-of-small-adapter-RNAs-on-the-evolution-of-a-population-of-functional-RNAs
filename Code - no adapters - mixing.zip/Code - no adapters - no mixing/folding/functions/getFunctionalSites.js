"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
const getFunctionalSites = (adapterSeq, adapterStr) => {
  adapterStr = Array.isArray(adapterStr) ? adapterStr[0] : adapterStr
  let regions = new Set();
  let start = 0;
  let prev = "";
  for (let i = 0; i < adapterStr.length; i++) {
    if (adapterStr[i] == "." && prev == "(") {
      start = i;
    } else if (adapterStr[i] == ")" && prev == ".") {
      regions.add(adapterSeq.slice(start, i));
    }
    prev = adapterStr[i];
  }
  let reverseRegions = new Set();
  regions.forEach(reg => {
    let out = "";
    for (let i = reg.length - 1; i >= 0; i--) {
      out += reg[i];
    }
    reverseRegions.add(out);
  });
  return new Set([...regions, ...reverseRegions]);
};



var _default = exports.default = getFunctionalSites;