"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _stackEnergies = _interopRequireDefault(require("../../lookupTables/stackEnergies"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const stack = (seq, i, j, p, q) => {
  return _stackEnergies.default[seq[i] + seq[j] + "/" + seq[p] + seq[q]];
};
var _default = exports.default = stack;
/*
Pairs represented in the JSON file as:
5' AG 3'
   ||  =  AG/CU
3' UC 5'

Note: this function does not takes AU or GU closing,
 symmetry, 
 and the special GGUC  helix to consideration
                 CUGG
*/