"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _adapterMatrix = _interopRequireDefault(require("./matrixFunctions/adapterMatrix"));
var _printMatrix = _interopRequireDefault(require("./matrixFunctions/printMatrix"));
var _getMinOfMatrix = _interopRequireDefault(require("./matrixFunctions/getMinOfMatrix"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const getBondSites = (rna, adapter) => {
  let pairMatrix = [...Array(adapter.length)].map(e => Array(rna.length).fill(undefined));
  let si = adapter.length - 1;
  let sj = rna.length - 1;
  while (sj > 0) {
    for (let i = si, j = sj; j < rna.length && i >= 0; i--, j++) {
      (0, _adapterMatrix.default)(adapter, rna, i, j, pairMatrix);
    }
    sj--;
  }
  while (si >= 0) {
    for (let i = si, j = sj; j < rna.length && i >= 0; i--, j++) {
      (0, _adapterMatrix.default)(adapter, rna, i, j, pairMatrix);
    }
    si--;
  }
  return (0, _getMinOfMatrix.default)(pairMatrix);
};
var _default = exports.default = getBondSites;