"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _v = _interopRequireDefault(require("./functions/matrixFunctions/v"));
var _w = _interopRequireDefault(require("./functions/matrixFunctions/w"));
var _wm = _interopRequireDefault(require("./functions/matrixFunctions/wm"));
var _dotBracket = _interopRequireDefault(require("./functions/dotBracket"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const fold = seq => {
  if (seq == "") return ["", 0];
  let matrices = {
    w: [...Array(seq.length)].map(e => Array(seq.length).fill(undefined)),
    v: [...Array(seq.length)].map(e => Array(seq.length).fill(undefined)),
    wm: [...Array(seq.length)].map(e => Array(seq.length).fill(undefined))
  };
  for (let i = 0; i < seq.length; i++) {
    //
    for (let j = i; j < seq.length; j++) {
      (0, _v.default)(seq, i, j, matrices), (0, _wm.default)(seq, i, j, matrices);
      (0, _w.default)(seq, i, j, matrices);
    }
  }

  /* console.log("V:");
  printMatrix(matrices.v);
   console.log("W:");
  printMatrix(matrices.w); */

  //console.log(...matrices.w[0][seq.length-1].pairs)

  if (matrices.w[0][seq.length - 1].mfe < 0) {
    return (0, _dotBracket.default)(seq, matrices.w[0][seq.length - 1]);
  } else {
    return (0, _dotBracket.default)(seq, {
      pairs: [],
      mfe: 0.0
    });
  }
};
var _default = exports.default = fold;