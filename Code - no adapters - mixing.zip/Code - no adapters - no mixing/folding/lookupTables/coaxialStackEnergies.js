"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = exports.default = JSON.parse(`{
    "DISCONSTACK": -2.1,
    "POTWCPAIRMM": -0.4,
    "POTGUPAIRMM": -0.2
}`);