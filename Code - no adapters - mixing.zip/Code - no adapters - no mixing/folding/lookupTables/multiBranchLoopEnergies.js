"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = exports.default = JSON.parse(`{
    "A":  930,
    "B":  90,
    "C": -90,
    "STRAIN": 310
}`);