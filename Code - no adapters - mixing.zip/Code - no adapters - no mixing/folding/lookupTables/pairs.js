"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = exports.default = JSON.parse(`{
    "ALL": ["AU", "CG", "GC", "GU", "UA", "UG"],
    "XU": ["AU", "GU", "UA", "UG"],
    "WATSONCRICK": ["AU", "CG", "GC", "GU", "UA", "UG"],
    "GU": ["GU", "UG"]
}`);