"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
class Struct {
  constructor(mfe, {
    pairs = [],
    exterior = []
  } = {}) {
    this.pairs = pairs;
    this.exterior = new Set(exterior);
    this.mfe = mfe;
  }
  addEnergy(e) {
    this.mfe += e;
  }
  addPair(e, pair) {
    this.mfe += e;
    this.pairs.push(pair);
  }
  addExterior(e, bases) {
    this.mfe += e;
    bases.forEach(b => {
      this.exterior.add(b);
    });
  }
  static clone(org) {
    return new Struct(org.mfe, {
      pairs: [...org.pairs],
      exterior: org.exterior
    });
  }
  static merge(a, b) {
    let mfe = a.mfe + b.mfe;
    const pairs = a.pairs.concat(b.pairs);
    let pairedBases = [];
    for (let i = 0; i < pairs.length; i++) {
      if (pairedBases.includes(pairs[i][0]) || pairedBases.includes(pairs[i][1])) {
        mfe = Infinity;
        break;
      }
      pairedBases.push(pairs[i][0]);
      pairedBases.push(pairs[i][1]);
    }
    const exterior = new Set([...a.exterior, ...b.exterior]);
    /* for (let i = 0; i < pairedBases.length; i++) {
        if (exterior.has(pairedBases[i])) {
            mfe = Infinity;
            break;
        }
    } */

    return new Struct(mfe, {
      pairs,
      exterior
    });
  }
}
var _default = exports.default = Struct;