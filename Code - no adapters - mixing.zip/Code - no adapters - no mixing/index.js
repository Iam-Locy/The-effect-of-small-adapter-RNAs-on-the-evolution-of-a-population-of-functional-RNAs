import Simulation from "cacatoo";
import randomRNA from "./randomRNA";
import { newCell, getFitness, getWRandom, copyCell } from "./cell";
import fold from "./folding/fold";

const run = async (_RNA) => {
    const L = 50;
    const target = ".......((((....))))(((((........))))).............";
    const RNA = _RNA;
    const mutationRate = 0.01;
    const date = new Date();
    const ID = `Control_mix_target_${target}_RNA_${RNA}_${date.getMonth()}_${date.getDate()}_${date.getHours()}_${date.getMinutes()}_${date.getSeconds()}`;

    const config = {
        title: `RNA evolution - Test - Target: ${target} - RNA: ${RNA}`,
        description: "",
        maxtime: 100,
        ncol: 20,
        nrow: 20,
        scale: 30,
        warp: [true, true],
    };

    let simulation = new Simulation(config);

    simulation.makeGridmodel("model");

    const logFile = `/tmp/lorinc/control/mix/Log_${ID}.txt`;
    const bpDistFile = `/tmp/lorinc/control/mix/Timestamps_bpDist_${ID}.txt`;
    const timestampFile = `/tmp/lorinc/control/mix/Timestamps_label_${ID}.txt`;
    const seqFile = `/tmp/lorinc/control/mix/Timestamps_seq_${ID}.txt`;

    if (!simulation.inbrowser) {
        simulation.write(`Target: ${target}\nRNA: ${RNA}\n`, logFile);
        simulation.write("", bpDistFile);
        simulation.write("", timestampFile);
        simulation.write("", seqFile);
    }

    const startingStr = fold(RNA)[0];

    for (let i = 0; i < config.ncol; i++) {
        for (let j = 0; j < config.nrow; j++) {
            simulation.model.grid[i][j] = newCell(
                target,
                RNA,
                startingStr,
                i,
                j,
                L
            );
        }
    }

    simulation.model.nextState = function (i, j) {
        const localPop = this.getNeighbours9(this, i, j, "");

        const canGrow = localPop.filter((c) => {
            return c.bpDist <= this.grid[i][j].bpDist;
        });
        const fitnesses = getFitness(canGrow);

        const next = getWRandom(canGrow, fitnesses);
        if (next != this.grid[i][j]) {
            this.grid[i][j] = copyCell(next, mutationRate, target, L);
        }
    };

    simulation.model.update = function () {
        let gridData = getGridData(this.grid, "bpDist");

        const gridDataOut = `
            Time: ${this.time}
            Max: ${JSON.stringify(gridData.max)}
            Min: ${JSON.stringify(gridData.min)}
            Mean ${gridData.mean}\n\n
        `;
        simulation.write_append(gridDataOut, logFile);

        simulation.write_append(`\nTime: ${this.time}\n`, bpDistFile);
        simulation.write_grid(this, "bpDist", bpDistFile, false);
        simulation.write_append(`\nTime: ${this.time}\n`, timestampFile);
        simulation.write_grid(this, "label", timestampFile, false);
        simulation.write_append(`\nTime: ${this.time}\n`, seqFile);
        simulation.write_grid(this, "rna", seqFile, false);

        this.perfectMix();
        this.synchronous();
    };

    const getGridData = (grid, property) => {
        let num = 0;
        let sum = 0;
        let max = undefined;
        let min = undefined;

        grid.forEach((col) => {
            col.forEach((gp) => {
                if (gp["seq"] != "") {
                    if (gp[property] > (max ? max[property] : -Infinity))
                        max = gp;
                    if (gp[property] < (min ? min[property] : Infinity))
                        min = gp;
                    sum += gp[property];
                    num++;
                }
            });
        });

        const mean = sum / num;

        return {
            max,
            min,
            mean,
        };
    };

    await simulation.start();
};

const starting = [
    "GGUGCAGCCAUGAAGGGGUGUUUUUCCGCCUGGCCAAAAUUGUAGGUGGU",
    "GCUCGGCGCGACCCUUCGCUUCCGUUCUACCAUGCCUACUCGCCUAACUG",
    "UAUCUGCCGAGCAUGUCGGACGCCAAUUGGGGGAUUUCAUUGUGUGCGUA",
    "AUCUUUAAGAAUGAUACAGGCACCCAGACGUUGCGCGUGAGACACUUGAA",
    "UGAGUGCCUCAGAAUAAUGCAGCGUCCAAUCCUGUCUUCUAACAGGAACC",
    "AGCUCAGAUGGAUCAUACAUGGGGACAUCAUAAUACCAACGUGCGCAAAC",
    "UUGACAUUAUAUUCAUUAGCUUGAAAGCGUUCCGUCAGAAAGGCCGUGUA",
    "GUUGGGGUAUCCCGCUGGAACACCGCCGGGCGUCUGUAUGUGUUUGCUGC",
    "UCUGCCCCAGAGACUCUGUUGUCUAAACAGCGAACCACUAAUAACUGAUG",
    "UGAGGUGAGCUCAUACGAUCAAUAAAUGCGCCUCACCGCCUAAACAUAUG",
];

for (let R = 0; R < starting.length; R++) {
    run(starting[R]);
}
