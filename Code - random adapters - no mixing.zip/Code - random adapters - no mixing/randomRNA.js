const randomRNA = (L) => {
    let rna = ''
    for(let i = 0; i < L; i++){
        rna += ["A", "C", "G", "U"][Math.floor(Math.random()*4)]
    }
    return rna
}

export default randomRNA