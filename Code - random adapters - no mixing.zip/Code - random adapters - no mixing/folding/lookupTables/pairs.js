"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = exports["default"] = JSON.parse("{\n    \"ALL\": [\"AU\", \"CG\", \"GC\", \"GU\", \"UA\", \"UG\"],\n    \"XU\": [\"AU\", \"GU\", \"UA\", \"UG\"],\n    \"WATSONCRICK\": [\"AU\", \"CG\", \"GC\", \"GU\", \"UA\", \"UG\"],\n    \"GU\": [\"GU\", \"UG\"]\n}");