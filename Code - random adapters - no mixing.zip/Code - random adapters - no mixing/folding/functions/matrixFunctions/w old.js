"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _v = _interopRequireDefault(require("./v"));
var _dangling = _interopRequireDefault(require("../energyFunctions/dangling"));
var _terminalMismatch = _interopRequireDefault(require("../energyFunctions/terminalMismatch"));
var _struct = _interopRequireDefault(require("../../struct"));
var _pairs = _interopRequireDefault(require("../../lookupTables/pairs"));
var _stackEnergies = _interopRequireDefault(require("../../lookupTables/stackEnergies"));
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}
var PAIRS = _pairs["default"].ALL;
var w = function w(seq, i, j, matrices) {
  if (matrices.w[i][j] != undefined) return matrices.w[i][j];
  var W = new _struct["default"](0);
  if (j - i <= 3) {
    matrices.w[i][j] = W;
    return W;
  }

  //Struct1: i and j pairs
  var struct1 = (0, _v["default"])(seq, i, j, matrices);

  //Penalty for AU, UA, GU, UG terminal pair, but only when it closes a stack
  if (_pairs["default"].XU.includes(seq[i] + seq[j])) {
    struct1 = _struct["default"].merge(struct1, new _struct["default"](_stackEnergies["default"].XUPENALTY));
  }

  /*Struct2: i is dangling
      A) i is dangling far from a stack*/
  var struct2 = w(seq, i + 1, j, matrices);

  /*  B) i is dangling next to an i+1 - j pair, but only when j is the last base*/
  if (PAIRS.includes(seq[i + 1] + seq[j]) && j == seq.length - 1) {
    var innerStruct = _struct["default"].merge((0, _v["default"])(seq, i + 1, j, matrices), new _struct["default"]((0, _dangling["default"])(seq, i, i + 1, j)));

    //Penalty for AU, UA, GU, UG terminal pair
    if (_pairs["default"].XU.includes(seq[i + 1] + seq[j])) {
      innerStruct = _struct["default"].merge(innerStruct, new _struct["default"](_stackEnergies["default"].XUPENALTY));
    }
    if (innerStruct.mfe < struct2.mfe) struct2 = innerStruct;
  }

  /*Struct3: j is dangling
      A) j is dangling far from a stack*/
  var struct3 = w(seq, i, j - 1, matrices);

  /*  B) j is dangling next to an i - j-1 pair, but only when i is the first base*/
  if (PAIRS.includes(seq[i] + seq[j - 1]) && i == 0) {
    var _innerStruct = _struct["default"].merge((0, _v["default"])(seq, i, j - 1, matrices), new _struct["default"]((0, _dangling["default"])(seq, i, j - 1, j)));

    //Penalty for AU, UA, GU, UG terminal pair
    if (_pairs["default"].XU.includes(seq[i] + seq[j - 1])) {
      _innerStruct = _struct["default"].merge(_innerStruct, new _struct["default"](_stackEnergies["default"].XUPENALTY));
    }
    if (_innerStruct.mfe < struct3.mfe) struct3 = _innerStruct;
  }

  /*Struct4: Both i and j are dangling
      A) They are dangling far from a stack*/
  var struct4 = w(seq, i + 1, j - 1, matrices);
  /*  B) They form a terminal mismatch*/
  if (PAIRS.includes(seq[i + 1] + seq[j - 1])) {
    var _innerStruct2 = _struct["default"].merge((0, _v["default"])(seq, i + 1, j - 1, matrices), new _struct["default"]((0, _terminalMismatch["default"])(seq, j - 1, i + 1, i, j)));
    //Penalty for AU, UA, GU, UG terminal pair
    if (_pairs["default"].XU.includes(seq[i + 1] + seq[j - 1])) {
      _innerStruct2 = _struct["default"].merge(_innerStruct2, new _struct["default"](_stackEnergies["default"].XUPENALTY));
    }
    if (_innerStruct2.mfe < struct4.mfe) struct4 = _innerStruct2;
  }

  //Struct5: Both i and j are form a pair, but not with each other
  var struct5 = new _struct["default"](Infinity);
  for (var k = i + 1; k < j; k++) {
    var _innerStruct3 = _struct["default"].merge(w(seq, i, k, matrices), w(seq, k + 1, j, matrices));
    if (_innerStruct3.mfe < struct5.mfe) struct5 = _innerStruct3;
  }
  [struct1, struct2, struct3, struct4, struct5].forEach(function (s) {
    if (s.mfe < W.mfe) W = s;
  });
  matrices.w[i][j] = W;
  return W;
};
var _default = exports["default"] = w;