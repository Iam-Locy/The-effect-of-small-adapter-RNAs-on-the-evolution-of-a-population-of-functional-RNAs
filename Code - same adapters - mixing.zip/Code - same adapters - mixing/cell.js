import fold from "./folding/fold";
import foldWithAdapter from "./folding/foldWithAdapter";
import bpDistance from "./folding/functions/bpDistance";
import randomRNA from "./randomRNA";

const newCell = (target, RNA, startingStr, _adapter, _adapterStr, i, j, L) => {
    const adapter = _adapter;
    const adapterStr = _adapterStr;
    const rna = RNA;
    const str = startingStr;
    const bpDist = bpDistance(str, target);
    const color = L - bpDist;

    const label =
        (i < 10 ? "0" : "") + i.toString() + (j < 10 ? "0" : "") + j.toString();

    usedLabels[label] = [];
    return {
        rna,
        str,
        bpDist,
        color,
        label,
        adapter,
        adapterStr,
    };
};

const getFitness = (pop) => {
    const D = pop
        .map((c) => {
            return c.bpDist;
        })
        .reduce((a, b) => a + b);

    if(D == 0){
        return Array(pop.length).fill(1/pop.length)
    }

    const Z = pop
        .map((c) => {
            return Math.exp(-c.bpDist / D);
        })
        .reduce((a, b) => a + b);

    return pop.map((c) => {
        return Math.exp(-c.bpDist / D) / Z;
    });
};

const getWRandom = (pop, w) => {
    const r = Math.random();

    let cumsum = 0;

    for (let i = 0; i < pop.length; i++) {
        cumsum += w[i];
        if (r <= cumsum) {
            return pop[i];
        }
    }

    return pop.slice(-1)[0];
};

const copyCell = (c, mut, t, L, A) => {
    let adapter = "";
    for (let i = 0; i < A; i++) {
        if (Math.random() < mut) {
            adapter += ["A", "C", "G", "U"][Math.floor(Math.random() * 4)];
        } else {
            adapter += c.adapter[i];
        }
    }

    let rna = "";
    for (let i = 0; i < L; i++) {
        if (Math.random() < mut) {
            rna += ["A", "C", "G", "U"][Math.floor(Math.random() * 4)];
        } else {
            rna += c.rna[i];
        }
    }

    const adapterStr = fold(adapter);
    const str = foldWithAdapter(rna, {
        seq: adapter,
        str: adapterStr,
    })[0];
    const bpDist = bpDistance(str, t);
    const color = L - bpDist;
    let label = c.label;

    if (str != c.str) {
        var abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
        var l1 = 0,
          l2 = 0,
          l3 = 0;
        while (true) {
          if (l3 >= abc.length) {
            l3 = 0;
            l2 += 1;
          }
          if (l2 >= abc.length) {
            l2 = 0, l3 = 0;
            l1 += 1;
          }
          var newLabel = c.label + "-" + abc[l1] + abc[l2] + abc[l3];
          if (!usedLabels[c.label].includes(newLabel)) {
            usedLabels[c.label].push(newLabel);
            usedLabels[newLabel] = [];
            label = newLabel;
            break;
          }
          l3 += 1;
        }
      }

    return {
        rna,
        str,
        bpDist,
        color,
        label,
        adapter,
        adapterStr,
    };
};

let usedLabels = {};

export { newCell, getFitness, getWRandom, copyCell };
